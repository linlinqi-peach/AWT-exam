# Task 1 submission notes

## App structure description

These are the most important files:
* `views/AboutView.js`: shows a page of general info about the app
* `views/HomeView.js`: initial view which shows welcome message
* `views/HomeView.js`: initial view which shows welcome message

## Implementation details

## Difficulties and Learnings


## Screen reader tests