const htmlTemplate = /*html*/`

<div>

    <router-link to="/spilledTea"><button> Spilled Tea </button> </router-link>
    <router-link to="/following"><button> Following </button> </router-link>
    <router-link to="/newPost"><button> ➕ </button> </router-link> 
  

</div>
`

export default {
  template: htmlTemplate
};