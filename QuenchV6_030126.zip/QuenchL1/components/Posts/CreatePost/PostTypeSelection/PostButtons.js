
const htmlTemplate = /*html*/`

<div>
<ul class="postBut">
    <li><router-link to="/"><button> Cancel </button> </router-link>  </li>
</ul>
</div>
`

export default {
  template: htmlTemplate,
  
};